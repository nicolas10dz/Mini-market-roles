package com.example.proyectojwt.dto;

import lombok.Data;

@Data
public class RefreshTokenResponseDTO {
    private String message;
    private String jwt;

}
