package com.example.proyectojwt.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.proyectojwt.entity.Product;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

}
