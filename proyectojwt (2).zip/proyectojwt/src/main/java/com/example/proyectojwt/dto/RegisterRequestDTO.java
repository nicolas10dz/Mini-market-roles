package com.example.proyectojwt.dto;

import lombok.Data;

@Data
public class RegisterRequestDTO {
    private String name;
    private String username;
    private String password;
    private String rol;

}
