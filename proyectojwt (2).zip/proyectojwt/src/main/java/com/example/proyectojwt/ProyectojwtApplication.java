package com.example.proyectojwt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectojwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectojwtApplication.class, args);
	}

}
