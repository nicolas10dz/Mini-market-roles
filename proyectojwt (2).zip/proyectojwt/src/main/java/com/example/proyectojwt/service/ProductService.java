package com.example.proyectojwt.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.example.proyectojwt.dto.HttpGlobalResponse;
import com.example.proyectojwt.dto.MessageResponseDTO;
import com.example.proyectojwt.dto.ProductRequestDTO;
import com.example.proyectojwt.dto.ProductResponseDTO;
import com.example.proyectojwt.entity.Product;
import com.example.proyectojwt.repository.ProductRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;

    public MessageResponseDTO createProduct(ProductRequestDTO requestDTO){
        MessageResponseDTO response = new MessageResponseDTO();
        Product product = new Product();
        product.setName(requestDTO.getName());
        product.setPrice(requestDTO.getPrice());
        product.setStock(requestDTO.getStock());
        productRepository.save(product);
        response.setMessage("Producto creado correctamente");
        return response;
    }

    public HttpGlobalResponse deleteProduct(Long id) {
        HttpGlobalResponse response = new HttpGlobalResponse<>();

        Product product = productRepository.findById(id).orElse(null);

        if (product == null) {
            response.setMessage("El producto no ha sido encontrado");
            return response;
            
        }
        productRepository.delete(product);
        response.setMessage("Producto eliminado correctamente");

        return response;
    }


    public HttpGlobalResponse<List<ProductResponseDTO>> listProducts(){
        List<ProductResponseDTO> response = new ArrayList<>();
        HttpGlobalResponse<List<ProductResponseDTO>> ProductResponse = new HttpGlobalResponse<>();
        List<Product> products = productRepository.findAll();

        if (products.isEmpty()) {
            throw new RuntimeException("No hay productos para mostrar");
        }

        for(Product product : products){
            ProductResponseDTO productResponseDTO = new ProductResponseDTO();
            productResponseDTO.setName(product.getName());
            productResponseDTO.setPrice(product.getPrice());
            productResponseDTO.setStock(product.getStock());
            response.add(productResponseDTO);
        }

        ProductResponse.setData(response);
        ProductResponse.setMessage("Productos listados correctamente");
        return ProductResponse;
        }

        public HttpGlobalResponse<ProductResponseDTO> getProduct (Long id) {
            HttpGlobalResponse<ProductResponseDTO> reponseProduct = new HttpGlobalResponse<>();

            Product products = productRepository.findById(id).orElse(null);

            if (products == null) {
                throw new RuntimeException("Producto no encontrado");
            }

            ProductResponseDTO productResponseDTO = new ProductResponseDTO();
            productResponseDTO.setName(products.getName());
            productResponseDTO.setPrice(products.getPrice());
            productResponseDTO.setStock(products.getStock());

            reponseProduct.setData(productResponseDTO);
            reponseProduct.setMessage("Producto obtenido correctamente");
            return reponseProduct;
        }


        public ProductResponseDTO updateProduct(Long id, ProductRequestDTO request) {

            Product product = productRepository.findById(id).orElse(null);

            if (product == null) {
                throw new RuntimeException("Producto no encontrado");
            }

            product.setName(request.getName());
            product.setPrice(request.getPrice());
            product.setStock(request.getStock());
            productRepository.save(product);

            ProductResponseDTO response = new ProductResponseDTO();
            response.setName(product.getName());
            response.setPrice(product.getPrice());
            response.setStock(product.getStock());

            return response;

    }
}




