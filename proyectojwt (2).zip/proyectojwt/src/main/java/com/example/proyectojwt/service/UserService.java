package com.example.proyectojwt.service;

import java.util.Optional;

import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.proyectojwt.dto.LoginRequestDTO;
import com.example.proyectojwt.dto.LoginResponseDTO;
import com.example.proyectojwt.dto.MessageResponseDTO;
import com.example.proyectojwt.dto.RefreshTokenResponseDTO;
import com.example.proyectojwt.dto.RegisterRequestDTO;
import com.example.proyectojwt.entity.User;
import com.example.proyectojwt.repository.UserRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class UserService {

    private final PasswordEncoder passwordEncoder;
    private final UserRepository userRepository;
    private final JwtService jwtService;

    public MessageResponseDTO register(RegisterRequestDTO request) {
        MessageResponseDTO response = new MessageResponseDTO();
        response.setMessage("Registro exitoso");

        if (userRepository.findByUsername(request.getUsername()).isPresent()) {
            throw new RuntimeException("Este nombre de usuario ya está en uso");
        }

        User user = new User();
        user.setName(request.getName());
        user.setUsername(request.getUsername());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setRol(request.getRol());
        userRepository.save(user);

        return response;
    }

    public LoginResponseDTO login(LoginRequestDTO request) {
        LoginResponseDTO response = new LoginResponseDTO();
        Optional<User> user = userRepository.findByUsername(request.getUsername());

        if (user.isEmpty() && request.getUsername() != null) {
            response.setMessage("Este usuario no se encuentra registrado");
            return response;
        }

        User userFound = user.get();

        if (!passwordEncoder.matches(request.getPassword(), userFound.getPassword())) {
            throw new RuntimeException("Contraseña incorrecta");
        }

        String jwt = jwtService.generateToken(userFound.getId(), userFound.getName(), userFound.getUsername(), userFound.getRol());

        response.setJwt(jwt);
        response.setMessage("Inicio de sesión exitoso");
        return response;
    }

    /**
     * Este metodo es para el refresco del token
     * @param token jwt viejo
     * @return nuevo token
     * @throws Exception
     */
    public RefreshTokenResponseDTO refreshToken(String token) throws Exception {
        String jwt = jwtService.refreshToken(token);
        RefreshTokenResponseDTO response = new RefreshTokenResponseDTO();
        response.setMessage("ok");
        response.setJwt(jwt);
        return response;
    }

}
