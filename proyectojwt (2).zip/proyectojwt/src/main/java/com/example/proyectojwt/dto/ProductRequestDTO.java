package com.example.proyectojwt.dto;

import java.math.BigDecimal;

import lombok.Data;

@Data
public class ProductRequestDTO {

    private String name;
    private BigDecimal price;
    private int stock;
}
