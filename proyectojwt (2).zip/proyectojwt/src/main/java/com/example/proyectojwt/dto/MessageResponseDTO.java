package com.example.proyectojwt.dto;

import lombok.Data;

@Data
public class MessageResponseDTO {
    private String message;

}
