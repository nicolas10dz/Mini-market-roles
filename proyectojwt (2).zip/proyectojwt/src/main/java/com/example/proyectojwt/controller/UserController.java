package com.example.proyectojwt.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.proyectojwt.dto.LoginRequestDTO;
import com.example.proyectojwt.dto.LoginResponseDTO;
import com.example.proyectojwt.dto.MessageResponseDTO;
import com.example.proyectojwt.dto.RegisterRequestDTO;
import com.example.proyectojwt.service.UserService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/user")
@RequiredArgsConstructor
public class UserController {
    private final UserService userService;

    /**
     * Registra un nuevo usuario en el sistema.
     * Este endpoint solo puede ser ejecutado por usuarios con rol ADMIN.
     *
     * @param httpRequest objeto que contiene la información de la petición HTTP,
     *                    incluyendo atributos como el rol del usuario autenticado.
     * @param request DTO con los datos necesarios para registrar un usuario.
     * @return ResponseEntity con un mensaje de éxito si el registro es correcto,
     *         o error 403 si el usuario no tiene permisos.
     */
    @PostMapping("/register")
    public ResponseEntity<MessageResponseDTO> register(HttpServletRequest httpRequest, @RequestBody RegisterRequestDTO request) {
        try {
            String rol = (String) httpRequest.getAttribute("rol");
            if (!rol.equals("ADMIN")) {
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(null);
            }
            MessageResponseDTO response = userService.register(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null); 
        }
    }

    /**
     * Realiza el inicio de sesión de un usuario.
     * Valida las credenciales y retorna un token JWT en caso de éxito.
     *
     * @param request DTO con username y password del usuario.
     * @return ResponseEntity con los datos de autenticación (token JWT) si es correcto,
     *         o error 400 si las credenciales son inválidas.
     */
    @PostMapping("/login")
    public ResponseEntity<LoginResponseDTO> login(@RequestBody LoginRequestDTO request) {
        try {
            LoginResponseDTO response = userService.login(request);
            return ResponseEntity.status(HttpStatus.ACCEPTED).body(response);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
        }
    }
}
