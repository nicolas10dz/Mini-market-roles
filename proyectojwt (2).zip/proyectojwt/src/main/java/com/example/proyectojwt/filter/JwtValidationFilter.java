package com.example.proyectojwt.filter;

import java.io.IOException;

import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.example.proyectojwt.service.JwtService;

import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;

/**
 * Filtro encargado de validar el JWT en cada petición HTTP.
 * Se ejecuta antes de llegar a los controladores (OncePerRequestFilter).
 *
 * Su función es:
 * - Verificar que el header Authorization exista
 * - Validar el token JWT
 * - Extraer información del usuario (username, userId, rol)
 * - Inyectar esos datos en el HttpServletRequest
 * - Bloquear la petición si el token es inválido o no existe
 */
@Component
@RequiredArgsConstructor
public class JwtValidationFilter extends OncePerRequestFilter {

    private final JwtService jwtService;

    /**
     * Ejecuta la lógica del filtro en cada petición HTTP.
     *
     * @param request petición HTTP entrante
     * @param response respuesta HTTP que se enviará al cliente
     * @param filterChain cadena de filtros de Spring
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws IOException {
        String autHeader = request.getHeader("Authorization");
        
        if (autHeader == null || !autHeader.startsWith("Bearer ")) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setContentType("application/json");
            response.getWriter().write("{\"error\": \"Header is missing in the request\"}");
            return;
        }

        String token = autHeader.replace("Bearer ", "");

        try {
            if (jwtService.isTokenValid(token)) {
                String username = jwtService.extractUsername(token);
                Long userId = jwtService.extractUserId(token);
                String rol = jwtService.extractRol(token);

                request.setAttribute("username", username);
                request.setAttribute("userId", userId);
                request.setAttribute("rol", rol);

                filterChain.doFilter(request, response);
            } else {
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.setContentType("application/json");
                response.getWriter().write("{\"error\":\"Token is invalid or expired\"}");
            }
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.setContentType("application/json");
            response.getWriter().write("{\"error\":\"Validation failed\"}");
        }
            }

    /**
     * Excluye rutas del filtro JWT.
     * En este caso, se permite el acceso libre al login.
     *
     * @param request petición HTTP
     * @return true si la petición NO debe pasar por el filtro
     */        
    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();
        return path.startsWith("/api/v1/proyectojwt/user/login");
    }    

}
