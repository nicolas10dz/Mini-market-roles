package com.example.proyectojwt.dto;

import lombok.Data;

@Data
public class UserRequestDTO {
    private String name;
    private String username;
    private String password;
    private String rol;

}
