package com.example.proyectojwt.service;

import java.util.Date;
import java.util.Map;
import java.util.function.Function;

import javax.crypto.SecretKey;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import lombok.extern.log4j.Log4j2;

@Service
@Log4j2
public class JwtService {
    
    @Value("${security.jwt.secret-key}")
    private String secretKey;

    @Value("${security.jwt.token-expiration}")
    private long tokenExpiration;

    /**
     *  Generar firma secreta a partir de nuestra secretKey del yaml
     * 
     * @return Firma secreta para general el jwt
     */
    private SecretKey getSigninKey(){
        byte[] keyBytes = Decoders.BASE64.decode(secretKey);
        return Keys.hmacShaKeyFor(keyBytes);
    }

    /**
     * Generar un jwt
     * 
     * @param userId
     * @param name
     * @param username
     * @param rol
     * @return String jwt
     */
    public String generateToken(Long userId, String name, String username, String rol) {
        return Jwts.builder() // se empieza a construir el jwt
        .claims(Map.of("userId", userId)) //Mapeamos el claim personalizado (claim: datos del payload que corresponden a la informacion del usuario)
        .claims(Map.of("name", name))
        .claims(Map.of("rol", rol)).subject(username) // a quien pertenece el token
        .issuedAt(new Date())
        .expiration(new Date(System.currentTimeMillis() + tokenExpiration)) // expiración del token expresada en ms (actualmente 10 min)
        .signWith(getSigninKey()) // Firmando con llave secreta del yaml
        .compact(); // Construye el string final
    }

    /**
     * Valida si el token es valido y si ha expirado o no
     * 
     * @param token
     * @return Boolean
     */
    public Boolean isTokenValid(String token) {
        try{
            //El parser intenta decifrar la firma con nuestra llave secreta
            Jwts.parser().verifyWith(getSigninKey()).build().parseSignedClaims(token);
            return true;
        } catch (JwtException e) {
            log.error("Token is invalid " + e.getMessage());
            return false;
        } catch (Exception e) {
            log.error("Ocurrió un error inesperado " + e.getMessage());
            return false;
        }
    }

    /**
     * Extrae todos los claims (payload) del token
     * 
     * @param <T>
     * @param token
     * @param resolver
     * @return resolver del claim
     */
    public <T> T extractClaims(String token, Function<Claims, T> resolver) {
        final Claims claims = Jwts.parser()
                .verifyWith(getSigninKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
                
        return resolver.apply(claims);        
    }

    /**
     * Extrae el propietario del token (nombre de usuario)
     * 
     * @param token
     * @return nombre de usuario
     */
    public String extractUsername(String token) {
        return extractClaims(token, Claims::getSubject);
    }

    /**
     * Extraer el id del usuario
     * 
     * @param token
     * @return id del usuario
     */
    public long extractUserId(String token) {
        return extractClaims(token, claims -> claims.get("userId", Long.class));
    }

    /**
     * Extraer el id del rol del usuario
     * 
     * @param token
     * @return id del rol del usuario
     */
    public String extractRol(String token) {
        return extractClaims(token, claims -> claims.get("rol", String.class));
    }

    public String refreshToken(String token) throws Exception {
        Claims claims;

        try {
            claims = Jwts.parser()
                    .verifyWith(getSigninKey())
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
        } catch (ExpiredJwtException e) {
            throw new Exception("Token is expired " + e.getMessage());
        } catch (JwtException e) {
            throw new Exception("Token is invalid " + e.getMessage());
        } catch (Exception e) {
            throw new Exception("Server error " + e.getMessage());  
        }

        return generateToken(
            claims.get("userId", Long.class),
            claims.get("name", String.class),
            claims.getSubject(),
            claims.get("rol", String.class));
        
    }

}
