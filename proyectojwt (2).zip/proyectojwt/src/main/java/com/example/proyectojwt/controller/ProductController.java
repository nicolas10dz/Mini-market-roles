package com.example.proyectojwt.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.proyectojwt.dto.HttpGlobalResponse;
import com.example.proyectojwt.dto.MessageResponseDTO;
import com.example.proyectojwt.dto.ProductRequestDTO;
import com.example.proyectojwt.dto.ProductResponseDTO;
import com.example.proyectojwt.service.ProductService;

import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/product")
@RequiredArgsConstructor
public class ProductController {

    /**
     * Servicio de productos
     * 
     * Solo usuarios con rol ADMIN pueden acceder a crear productos
     * 
     * @param httpRequest es el request HTTP actual
     * @param requesDTO datos del producto a crear
     * @return mensaje de respuesta
     */
    private final ProductService productService;
    @PostMapping
    public ResponseEntity<?> createProduct (HttpServletRequest httpRequest, @RequestBody ProductRequestDTO requestDTO){

        try{

            String rol = (String) httpRequest.getAttribute("rol");
            if (!rol.equals("ADMIN")) {
                MessageResponseDTO error = new MessageResponseDTO();
            error.setMessage("No tienes permisos para realizar esta acción");
                return ResponseEntity.status(HttpStatus.FORBIDDEN).body(error);
            }
            MessageResponseDTO response = productService.createProduct(requestDTO);
            return ResponseEntity.status(HttpStatus.CREATED).body(response);
        } catch (Exception e) {
            e.printStackTrace();
            MessageResponseDTO error = new MessageResponseDTO();
            error.setMessage(e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(error);
        }
    }

    /**
     * Endpoint para listar todos los productos
     * 
     * Puede accerder el ADMIN y CAJERO
     * 
     * @return lista de productos
     */
    @GetMapping
    public ResponseEntity<HttpGlobalResponse<List<ProductResponseDTO>>> listProducts() {
        HttpGlobalResponse<List<ProductResponseDTO>> response = new HttpGlobalResponse<>();
        try{
            response = productService.listProducts();
            return ResponseEntity.status(HttpStatus.OK).body(response);
        } catch (Exception e) {
            response.setMessage(e.getMessage());
            return ResponseEntity.status(HttpStatus.NO_CONTENT).body(response);
        }
    }

    /**
     * Endpoint para consultar un producto por id
     * 
     * Puede acceder el ADMIN y CAJERO
     * 
     * @param id del producto
     * @return producto encontrado
     */
    @GetMapping("/{id}")
    public ResponseEntity<HttpGlobalResponse<ProductResponseDTO>> getProduct(@PathVariable long id){
        HttpGlobalResponse<ProductResponseDTO> response = new HttpGlobalResponse<>();
        try{
            response = productService.getProduct(id);
            return ResponseEntity.status(HttpStatus.OK).body(response);
        } catch(Exception e) {
            response.setMessage(e.getMessage());
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }
    }

    /**
     * Endpoint para eliminar productos
     * 
     * solo ADMIN puede eliminar productos
     * 
     * @param httpRequest HTTP actual
     * @param id del producto
     * @return mensaje de respuesta
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteProduct(HttpServletRequest httpRequest, @PathVariable Long id){
        String rol = (String) httpRequest.getAttribute("rol");
        if (!rol.equals("ADMIN")) {
            MessageResponseDTO error = new MessageResponseDTO();
            error.setMessage("No tienes permisos para realizar esta acción");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(error);
            
        }
        HttpGlobalResponse response = productService.deleteProduct(id);

        return ResponseEntity.ok(response);
    }


    /**
     * Endpoint para actualizar productos
     * 
     * Solo ADMIN puede actualizar productos
     * 
     * @param httpRequest HTTP actual
     * @param id del producto
     * @param request datos nuevos del producto
     * @return producto actualizado
     */
    @PutMapping("/{id}")
    public ResponseEntity<?> updateProduct(HttpServletRequest httpRequest, @PathVariable Long id, @RequestBody ProductRequestDTO request) {

        String rol = (String) httpRequest.getAttribute("rol");

        if (!rol.equals("ADMIN")) {
            MessageResponseDTO error = new MessageResponseDTO();
            error.setMessage("No tienes permisos para realizar esta acción");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(error);
        }

        ProductResponseDTO productNew = productService.updateProduct(id, request);

        HttpGlobalResponse<ProductResponseDTO> response = new HttpGlobalResponse<>();
        response.setMessage("Producto actualizado correctamente");
        response.setData(productNew);

        return ResponseEntity.ok(response);
    }

}
