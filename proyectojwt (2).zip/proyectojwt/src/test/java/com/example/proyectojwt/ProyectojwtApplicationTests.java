package com.example.proyectojwt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectojwtApplicationTests {

	@Test
	void contextLoads() {
	}

}
